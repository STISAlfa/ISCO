<?php

class Essay extends Eloquent {
	protected $table  = "essay";
}