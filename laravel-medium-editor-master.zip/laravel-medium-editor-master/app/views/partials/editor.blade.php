<script src="//code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.1/js/bootstrap.min.js"></script>
<script src="{{ url('js/medium-editor.js') }}"></script>
<script src="{{ url('js/medium-editor-insert.js') }}"></script>
<script src="{{ url('js/main.js') }}"></script>